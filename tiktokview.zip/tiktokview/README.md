#### Paid unpatched viewbot for 24.99€ !!: https://onlp.sellix.io or in dc server 
repo works again, maybe needs proxies but here you go

<h2 align="center">server: <a href="https://discord.gg/onlp">discord.gg/onlp</a></h2>

<!--
<p align="center">
400 followers / 500 stars = leaked unpatched viewbot 1k/s
</p>
-->

&emsp;

<h2 align="center">tutorial: <a href="https://www.youtube.com/watch?v=x97aLsPSJtQ">youtube.com/watch?v=x97aLsPSJtQ</a></h2>

<!--
<p align="center">
<del>100 stars = captcha solver</del>
</p><p align="center">
<del>170 stars = open source solver</del>
</p><p align="center">
200 stars = viewbot in golang + proxy support + bot multiple videos same time (SOON, on vacation rn so can't release)
</p><p align="center">
250 stars = viewbot using freer api (2x faster)
</p><p align="center">
500 stars = unpatched viewbot using real tiktok api
</p>
-->

<!--

<p align="center"> 
<img src="https://global.tiktokworld21.com/images/TT_Logo.png"></img>
</p>

-->

<p align="center"> 
<img src="https://cdn.discordapp.com/attachments/979095432682676264/996481048605106186/unknown.png"></img>
</p>

skids:
```
  https://github.com/XNorealsS/tiktokbot-view
  https://github.com/haphucduy28/1/blob/main/viewtiktok.py
```

How to run:
```
  1. Verify that you have pip and python installed => https://www.youtube.com/watch?v=dYfKJMPNMDw
  2. Run this command in cmd: pip install requests bs4 cursor pystyle pillow
  3. replace the video id in config.json by yours
  4. run the python file by double clicking on it or type: python viewbot.py
```

Advantages:
```
  1.  fast, easy
  2.  lightweight
  3.  Has dynamic views count running on TikTok API
  4.  mobile users can run it
```
To come:
```
  1. Proxy support
  3. Bot using freer api so 2x faster (freer api is gay)
```
